Python package to aggregate datasets used in the early warning project
